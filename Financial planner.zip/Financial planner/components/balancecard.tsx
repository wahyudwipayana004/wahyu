import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import { Pressable, StyleSheet, Text } from "react-native";

export default function BalanceCard() {
  return (
    <LinearGradient
      colors={["#9C27B0", "#E91E63"]}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={styles.card}
    >
      <Text style={styles.label}>Saldo</Text>

      <Text style={styles.amount}>Rp 2.750.000</Text>

      <Pressable style={styles.button} onPress={() => router.push("/wallet")}>
        <Text style={styles.buttonText}>Lihat detail</Text>
      </Pressable>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  card: {
    width: "100%",

    padding: 25,
    borderRadius: 20,
    marginTop: 20,
  },
  label: {
    color: "#fff",
    fontSize: 18,
    opacity: 0.8,
  },
  amount: {
    color: "#fff",
    fontSize: 36,
    fontWeight: "bold",
    marginVertical: 5,
  },
  button: {
    marginTop: 15,
    backgroundColor: "rgba(255,255,255,0.25)", // transparent white
    paddingVertical: 10,
    borderRadius: 12,
    alignItems: "center",
  },
  buttonText: {
    color: "#fff",
    fontWeight: "600",
    fontSize: 14,
  },
});
