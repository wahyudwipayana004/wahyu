import { Image, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

export default function Profile() {
  return (
    <SafeAreaView style={{ flex: 1 }}>
      <View style={styles.container}>
        <Image
          source={{ uri: "https://i.pravatar.cc/200" }}
          style={styles.avatar}
        />

        <Text style={styles.name}>Windu</Text>
        <Text style={styles.email}>windu@example.com</Text>

        <View style={styles.card}>
          <Text style={styles.cardTitle}>Status Keuangan</Text>
          <Text style={styles.cardText}>
            Stabil • Baik • Rekomendasi menabung Rp 500.000/bulan
          </Text>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    padding: 20,
    backgroundColor: "#fff",
  },
  avatar: { width: 110, height: 110, borderRadius: 60, marginBottom: 15 },
  name: { fontSize: 22, fontWeight: "bold", color: "#82167cff" },
  email: { color: "#777", marginBottom: 20 },
  card: {
    width: "100%",
    backgroundColor: "#d084cfff",
    padding: 20,
    borderRadius: 15,
  },
  cardTitle: { fontSize: 18, fontWeight: "bold", color: "#9C27B0" },
  cardText: { fontSize: 14, marginTop: 5 },
});
