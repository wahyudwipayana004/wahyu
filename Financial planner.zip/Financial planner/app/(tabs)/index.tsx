import BalanceCard from "@/components/balancecard";
import DonutChart from "@/components/donutchart";
import React from "react";
import { ScrollView, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

export default function index() {
  return (
    <SafeAreaView style={{ flex: 1 }}>
      <ScrollView style={styles.container}>
        <BalanceCard />
        <Text style={styles.overview}>Overview</Text>
        <View style={styles.chartcard}>
          <DonutChart shopping={40} food={35} bills={25} />

          <View style={styles.categoriesContainer}>
            <View style={styles.categoryRow}>
              <View style={[styles.dot, { backgroundColor: "#ff7aa8" }]} />
              <Text style={styles.categoryLabel}>Shopping</Text>
              <Text style={styles.categoryValue}>Rp 2.300.000</Text>
            </View>

            <View style={styles.categoryRow}>
              <View style={[styles.dot, { backgroundColor: "#ffe47a" }]} />
              <Text style={styles.categoryLabel}>Bayar Bulanan</Text>
              <Text style={styles.categoryValue}>Rp 1.200.000</Text>
            </View>

            <View style={styles.categoryRow}>
              <View style={[styles.dot, { backgroundColor: "#7acbff" }]} />
              <Text style={styles.categoryLabel}>Makanan</Text>
              <Text style={styles.categoryValue}>Rp 900.000</Text>
            </View>
          </View>
        </View>
        <View style={styles.containerRek}>
          <Text style={styles.rekomendasi}>Rekomendasi</Text>
          <Text style={styles.rekomendasiDetail}>
            Kurangi pengeluaran makan diluar
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  overview: {
    padding: 10,
    marginTop: 10,
    fontWeight: "bold",
    fontSize: 20,
  },
  chartcard: {
    backgroundColor: "#ffffffff",
    shadowColor: "#000",
    shadowOpacity: 0.15,
    shadowRadius: 1,
    elevation: 3,
    padding: 15,
    borderRadius: 8,
    marginBottom: 10,
  },
  container: {
    flex: 1,
    backgroundColor: "#F8FAF9",
    padding: 20,
  },
  categoriesContainer: {
    marginTop: 25,
    width: "100%",
    paddingHorizontal: 10,
  },

  categoryRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 12,
    paddingVertical: 6,
  },

  dot: {
    width: 14,
    height: 14,
    borderRadius: 7,
    marginRight: 10,
  },

  categoryLabel: {
    flex: 1,
    fontSize: 16,
    fontWeight: "600",
    color: "#333",
  },

  categoryValue: {
    fontSize: 16,
    fontWeight: "700",
    color: "#111",
  },
  containerRek: {
    backgroundColor: "#ffffffff",
    shadowColor: "#000",
    shadowOpacity: 0.15,
    shadowRadius: 1,
    elevation: 3,
    padding: 15,
    borderRadius: 8,
    marginTop: 5,
    marginBottom: 30,
  },
  rekomendasi: {
    padding: 10,
    marginTop: 10,
    fontWeight: "bold",
    fontSize: 20,
  },
  rekomendasiDetail: {
    paddingLeft: 10,
    marginBottom: 50,
    fontSize: 15,
  },
});
