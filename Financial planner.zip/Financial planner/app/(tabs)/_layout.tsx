import { Ionicons } from "@expo/vector-icons";
import { Tabs } from "expo-router";
import React from "react";
import { Platform } from "react-native";

export default function Layout() {
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: "#9C27B0", // warna aktif
        tabBarInactiveTintColor: "#B6B6C8", // warna nonaktif
        tabBarStyle: {
          backgroundColor: "#FFFFFF",
          borderTopWidth: 0,
          elevation: 3,
          height: Platform.OS === "ios" ? 85 : 65,
          paddingBottom: 10,
        },
        tabBarLabelStyle: {
          fontSize: 12,
          fontWeight: "600",
        },
      }}
    >
      {/* Dashboard */}
      <Tabs.Screen
        name="index"
        options={{
          title: "Home",
          tabBarIcon: ({ focused, color, size }) => (
            <Ionicons
              name={focused ? "home-sharp" : "home-outline"}
              size={size}
              color={color}
            />
          ),
        }}
      />

      {/* Simulasi */}
      <Tabs.Screen
        name="simulation"
        options={{
          title: "Simulasi",
          tabBarIcon: ({ focused, color, size }) => (
            <Ionicons
              name={focused ? "calculator-sharp" : "calculator-outline"}
              size={size}
              color={color}
            />
          ),
        }}
      />

      {/* Edukasi */}
      <Tabs.Screen
        name="education"
        options={{
          title: "Edukasi",
          tabBarIcon: ({ focused, color, size }) => (
            <Ionicons
              name={focused ? "book-sharp" : "book-outline"}
              size={size}
              color={color}
            />
          ),
        }}
      />

      {/* Profil */}
      <Tabs.Screen
        name="profile"
        options={{
          title: "Profil",
          tabBarIcon: ({ focused, color, size }) => (
            <Ionicons
              name={focused ? "person-sharp" : "person-outline"}
              size={size}
              color={color}
            />
          ),
        }}
      />
    </Tabs>
  );
}
