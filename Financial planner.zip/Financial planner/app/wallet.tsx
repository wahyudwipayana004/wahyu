import { LinearGradient } from "expo-linear-gradient";
import React from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";

export default function wallet() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Wallet</Text>

      <LinearGradient
        colors={["#9C27B0", "#E91E63"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.card}
      >
        <Text style={styles.label}>Pemasukan</Text>
        <Text style={styles.value}>Rp 5.670.000</Text>

        <Text style={styles.label}>Pengeluaran</Text>
        <Text style={styles.value}>Rp 2.230.000</Text>

        <View style={styles.line} />

        <Text style={styles.saldoLabel}>Saldo</Text>
        <Text style={styles.saldo}>Rp 2.750.000</Text>
      </LinearGradient>
      <Pressable
        style={({ pressed }) => [styles.fab, { opacity: pressed ? 0.7 : 1 }]}
      >
        <Text style={styles.fabText}>+</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: "#f5f5f5",
  },

  title: {
    fontSize: 32,
    fontWeight: "700",
    marginBottom: 20,
    color: "#870c6aff",
  },

  card: {
    padding: 20,
    borderRadius: 22,
    shadowColor: "#000",
    shadowOpacity: 0.15,
    shadowRadius: 10,
    elevation: 8,
  },

  label: {
    fontSize: 16,
    color: "#e3e3e3",
    marginTop: 10,
  },

  value: {
    fontSize: 22,
    fontWeight: "600",
    color: "#fff",
  },

  line: {
    height: 1,
    backgroundColor: "rgba(255,255,255,0.3)",
    marginVertical: 15,
  },

  saldoLabel: {
    fontSize: 18,
    fontWeight: "700",
    color: "#fff",
  },

  saldo: {
    fontSize: 30,
    fontWeight: "800",
    color: "#fff",
    marginTop: 4,
  },
  fab: {
    position: "absolute",
    bottom: 25,
    right: 25,
    backgroundColor: "#4e54c8",
    width: 60,
    height: 60,
    borderRadius: 30,
    justifyContent: "center",
    alignItems: "center",

    elevation: 6,
    shadowColor: "#000",
    shadowOpacity: 0.2,
    shadowRadius: 5,
    shadowOffset: { width: 0, height: 3 },
  },

  fabText: {
    fontSize: 34,
    color: "#fff",
    marginTop: -2,
  },
});
